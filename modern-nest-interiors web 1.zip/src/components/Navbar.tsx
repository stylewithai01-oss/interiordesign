import { useState, useEffect } from 'react';
import { Menu, X, Instagram, Facebook, Youtube, Moon, Sun, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../i18n/LanguageContext';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const NAV_LINKS = [
    { name: t('nav.home'), href: '#home' },
    { name: t('nav.services'), href: '#services' },
    { name: t('nav.portfolio'), href: '#portfolio' },
    { name: t('nav.contact'), href: '#contact' },
  ];

  useEffect(() => {
    // Check initial preference from localStorage or system
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      setIsDark(true);
    }
  }, []);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 dark:bg-charcoal-900/95 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo Left */}
        <a href="#home" className={`text-xl sm:text-2xl font-serif tracking-tight z-50 relative transition-colors ${isScrolled ? 'text-charcoal-900 dark:text-white' : 'text-white'}`}>
          Modern Nest
          <span className="text-gold-500">.</span>
        </a>

        <div className="flex items-center gap-4 z-50">
          {/* Language Switcher - Always Visible */}
          <div className={`relative group flex items-center gap-2 cursor-pointer border border-gold-500/50 rounded-full px-2 sm:px-3 py-1 sm:py-1.5 bg-white/5 dark:bg-black/20 hover:border-gold-500 transition-all shadow-sm ${isScrolled ? 'text-charcoal-800 dark:text-white' : 'text-white'}`}>
            <Globe size={14} className="text-gold-500" />
            <select 
              value={language}
              onChange={(e) => setLanguage(e.target.value as 'en' | 'kn')}
              className="bg-transparent text-[9px] sm:text-[10px] uppercase tracking-widest font-bold appearance-none cursor-pointer focus:outline-none pr-1 dark:text-white"
            >
              <option value="en" className="text-charcoal-900 bg-white">English</option>
              <option value="kn" className="text-charcoal-900 bg-white">ಕನ್ನಡ</option>
            </select>
          </div>

          {/* Desktop Nav Right */}
          <div className="hidden md:flex items-center gap-8 ml-4">
            <div className="flex items-center gap-6 mr-4">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className={`text-sm font-medium tracking-wider uppercase hover:text-gold-500 transition-colors ${isScrolled ? 'text-charcoal-800 dark:text-gray-300' : 'text-white/90'}`}
                >
                  {link.name}
                </a>
              ))}
            </div>

            <div className="h-4 w-px bg-gray-300 dark:bg-gray-600 mx-2 hidden lg:block"></div>

            {/* Controls & Social (Desktop) */}
            <div className={`flex items-center gap-4 transition-colors ${isScrolled ? 'text-charcoal-800 dark:text-gray-300' : 'text-white/90'}`}>
              <button 
                onClick={() => setIsDark(!isDark)} 
                className="hover:text-gold-500 transition-colors mr-2 cursor-pointer"
                aria-label="Toggle Dark Mode"
              >
                {isDark ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <a href="#" className="hover:text-gold-500 transition-colors" aria-label="Instagram">
                <Instagram size={18} />
              </a>
              <a href="#" className="hover:text-gold-500 transition-colors" aria-label="Facebook">
                <Facebook size={18} />
              </a>
              <a href="#" className="hover:text-gold-500 transition-colors" aria-label="YouTube">
                <Youtube size={20} strokeWidth={1.5} />
              </a>
            </div>
          </div>

          {/* Mobile Nav Toggle */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={() => setIsDark(!isDark)} 
              className={`cursor-pointer transition-colors ${isScrolled ? 'text-charcoal-900 dark:text-white' : 'text-white'}`}
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button
              className={`relative transition-colors ${isScrolled ? 'text-charcoal-900 dark:text-white' : 'text-white'}`}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} className="text-charcoal-900 dark:text-white" /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed inset-0 bg-white dark:bg-charcoal-900 z-40 flex flex-col justify-center items-center gap-8 pt-20"
            >
              {NAV_LINKS.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-2xl font-serif text-charcoal-900 dark:text-white hover:text-gold-500 transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              
              <div className="flex gap-6 mt-8 text-charcoal-900 dark:text-white">
                <a href="#" className="hover:text-gold-500 transition-colors"><Instagram size={24} /></a>
                <a href="#" className="hover:text-gold-500 transition-colors"><Facebook size={24} /></a>
                <a href="#" className="hover:text-gold-500 transition-colors"><Youtube size={26} strokeWidth={1.5} /></a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}
