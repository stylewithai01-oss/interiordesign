export function Footer() {
  return (
    <footer className="bg-charcoal-900 text-white py-16 border-t border-gray-800">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 border-b border-gray-800 pb-12 mb-8">
          <a href="#home" className="text-2xl font-serif tracking-tight">
            Modern Nest
            <span className="text-gold-500">.</span>
          </a>
          
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm font-medium tracking-wide uppercase text-gray-400">
            <a href="#home" className="hover:text-gold-500 transition-colors">Home</a>
            <a href="#services" className="hover:text-gold-500 transition-colors">Services</a>
            <a href="#portfolio" className="hover:text-gold-500 transition-colors">Portfolio</a>
            <a href="#contact" className="hover:text-gold-500 transition-colors">Contact</a>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-light text-gray-500">
          <div>
            &copy; {new Date().getFullYear()} Modern Nest Interiors. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-gray-300 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gray-300 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
