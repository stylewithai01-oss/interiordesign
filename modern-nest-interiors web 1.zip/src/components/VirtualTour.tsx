import { useRef, useState, MouseEvent, TouchEvent } from 'react';
import { motion } from 'motion/react';
import { MousePointer2, MoveHorizontal } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export function VirtualTour() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();
  const [bgPositionX, setBgPositionX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);

  const startDrag = (x: number) => {
    setIsDragging(true);
    setStartX(x - bgPositionX);
  };

  const handleDrag = (x: number) => {
    if (!isDragging) return;
    // Sensivity multiplier for better rotation feel
    const delta = (x - startX);
    setBgPositionX(delta);
  };

  const stopDrag = () => {
    setIsDragging(false);
  };

  // Mouse Handlers
  const onMouseDown = (e: MouseEvent) => {
    e.preventDefault();
    startDrag(e.pageX);
  };
  const onMouseMove = (e: MouseEvent) => handleDrag(e.pageX);
  
  // Touch Handlers
  const onTouchStart = (e: TouchEvent) => startDrag(e.touches[0].pageX);
  const onTouchMove = (e: TouchEvent) => handleDrag(e.touches[0].pageX);

  return (
    <section className="py-24 bg-charcoal-900 text-white overflow-hidden">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-400 mb-4 font-semibold"
          >
            {t('tour.tag')}
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif leading-tight font-light"
          >
            {t('tour.title')} <span className="italic text-gold-400">{t('tour.accent')}</span>.
          </motion.h2>
          <p className="text-gray-400 mt-4 font-light text-lg">{t('tour.desc')}</p>
        </div>
      </div>

      <div className="max-w-[100%] mx-auto px-4 md:px-12 relative cursor-grab active:cursor-grabbing group">
        <motion.div 
          ref={containerRef}
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="relative w-full aspect-video md:aspect-[21/9] bg-charcoal-800 rounded-lg overflow-hidden border border-gray-800 select-none shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={stopDrag}
          onMouseLeave={stopDrag}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={stopDrag}
          style={{
            backgroundImage: `url('https://pannellum.org/images/alma.jpg')`,
            backgroundSize: 'cover',
            backgroundPosition: `${bgPositionX}px center`,
            backgroundRepeat: 'repeat-x',
          }}
        >
          {/* Virtual Compass Overlay */}
          <div className="absolute bottom-8 right-8 z-30 pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity">
            <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center">
              <div 
                className="w-1 h-8 bg-gold-400 rounded-full origin-bottom"
                style={{ transform: `rotate(${bgPositionX / 5}deg)` }}
              ></div>
            </div>
          </div>

          {/* Overlay hints */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-active:opacity-0 transition-opacity duration-300 pointer-events-none">
             <div className="bg-charcoal-900/80 backdrop-blur-md px-6 py-3 rounded-full flex items-center gap-3 border border-gold-500/30 text-gold-400 shadow-xl">
                <MoveHorizontal size={24} className="animate-bounce-x" />
                <span className="uppercase tracking-widest text-[10px] font-bold">{t('tour.label')}</span>
             </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
