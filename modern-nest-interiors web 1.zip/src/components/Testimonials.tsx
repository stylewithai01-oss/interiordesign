import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, X, Upload } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

// Initial Mock Reviews
const INITIAL_REVIEWS = [
  {
    id: 1,
    name: "Eleanor Sterling",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    text: "Modern Nest completely transformed our penthouse. The attention to detail and sophisticated use of space exceeded every expectation. An absolute masterpiece."
  },
  {
    id: 2,
    name: "Jameson Wright",
    photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    text: "The bespoke modular kitchen they designed for us is both a functional workspace and a work of art. The team's professionalism is unmatched."
  },
  {
    id: 3,
    name: "Sophia Carter",
    photo: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    text: "Our corporate office now perfectly reflects our brand's prestige. They merged luxury with ergonomics beautifully."
  }
];

export function Testimonials() {
  const [reviews, setReviews] = useState(INITIAL_REVIEWS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [ratingInput, setRatingInput] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would upload the image and save to database.
    // For now, we gently close it and show a success state or just update local state.
    setIsModalOpen(false);
    setRatingInput(0);
    // Resetting form would happen here
    alert("Thank you for your review!");
  };

  return (
    <section id="testimonials" className="py-24 md:py-32 bg-gray-50 dark:bg-charcoal-800 border-t border-gray-200 dark:border-gray-800 transition-colors duration-300">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold"
          >
            Client Experiences
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif leading-tight font-light text-charcoal-900 dark:text-white"
          >
            Testimonials & <span className="italic text-gray-500">Reviews</span>.
          </motion.h2>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="bg-white dark:bg-charcoal-900 p-10 shadow-sm border border-gray-100 dark:border-gray-800 rounded-sm hover:-translate-y-2 hover:shadow-lg transition-all duration-300 flex flex-col"
            >
              <div className="flex items-center gap-4 mb-6">
                <img 
                  src={review.photo} 
                  alt={review.name} 
                  className="w-16 h-16 rounded-full object-cover border border-gray-200 dark:border-gray-700 p-1"
                />
                <div>
                  <h3 className="font-serif text-lg text-charcoal-900 dark:text-white">{review.name}</h3>
                  <div className="flex gap-1 mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={14} 
                        className={i < review.rating ? "fill-gold-500 text-gold-500" : "fill-gray-200 dark:fill-gray-700 text-gray-200 dark:text-gray-700"} 
                      />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-400 font-light leading-relaxed italic flex-grow">
                "{review.text}"
              </p>
            </motion.div>
          ))}
        </div>

        {/* Submit Review CTA */}
        <div className="text-center">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="border border-charcoal-900 dark:border-white text-charcoal-900 dark:text-white hover:bg-charcoal-900 dark:hover:bg-white hover:text-white dark:hover:text-charcoal-900 px-8 py-4 uppercase tracking-wider text-sm transition-colors duration-300 inline-block font-medium"
          >
            Submit a Review
          </button>
        </div>
      </div>

      {/* Submit Review Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-charcoal-900/80 backdrop-blur-sm"
          >
             <motion.div 
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white w-full max-w-lg shadow-2xl relative rounded-sm overflow-hidden"
             >
                {/* Modal Header */}
                <div className="bg-charcoal-900 p-6 flex justify-between items-center text-white text-center relative border-b border-gold-500/30">
                  <h3 className="font-serif text-2xl tracking-wide w-full">Share Your Experience</h3>
                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="absolute right-6 text-gray-400 hover:text-white transition-colors"
                  >
                    <X size={24} />
                  </button>
                </div>

                {/* Modal Form */}
                <form onSubmit={handleReviewSubmit} className="p-8 space-y-6">
                  
                  {/* Rating Selector */}
                  <div className="flex flex-col items-center justify-center gap-2 mb-4">
                    <span className="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-1">Your Rating</span>
                    <div className="flex gap-2 cursor-pointer">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star}
                          size={28}
                          onMouseEnter={() => setHoveredRating(star)}
                          onMouseLeave={() => setHoveredRating(0)}
                          onClick={() => setRatingInput(star)}
                          className={`transition-colors ${(hoveredRating || ratingInput) >= star ? "fill-gold-500 text-gold-500" : "fill-gray-100 text-gray-300 hover:text-gold-400"}`}
                        />
                      ))}
                    </div>
                  </div>

                  <div>
                    <input 
                      type="text" 
                      required
                      placeholder="Your Full Name" 
                      className="w-full bg-transparent border-b border-gray-300 py-3 px-0 text-charcoal-900 placeholder-gray-400 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm"
                    />
                  </div>

                  <div className="relative">
                    <input 
                      type="file" 
                      id="photo-upload" 
                      className="hidden" 
                      accept="image/*"
                    />
                    <label 
                      htmlFor="photo-upload" 
                      className="flex items-center gap-3 w-full bg-gray-50 border border-dashed border-gray-300 py-4 px-4 text-gray-500 hover:bg-gray-100 hover:border-gold-500 cursor-pointer transition-colors font-light text-sm justify-center rounded-sm"
                    >
                      <Upload size={18} className="text-gold-500" />
                      <span>Upload Project Photo or Profile Pic</span>
                    </label>
                  </div>

                  <div>
                    <textarea 
                      required
                      placeholder="Tell us about the design process and final space..." 
                      rows={4}
                      className="w-full bg-transparent border-b border-gray-300 py-3 px-0 text-charcoal-900 placeholder-gray-400 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm resize-none"
                    ></textarea>
                  </div>

                  <button 
                    type="submit" 
                    className="bg-charcoal-900 hover:bg-gold-500 text-white px-8 py-4 w-full uppercase tracking-widest text-xs font-semibold transition-colors mt-2"
                  >
                    Submit Review
                  </button>
                </form>
             </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
