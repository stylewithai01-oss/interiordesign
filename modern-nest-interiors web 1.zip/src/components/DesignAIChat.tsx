import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Send, Bot, Loader2, User, Image as ImageIcon, 
  Mic, MicOff, Paperclip, Trash2, CheckCircle2 
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface Message {
  role: 'user' | 'model';
  text: string;
  image?: string; // Base64
}

const SYSTEM_INSTRUCTION = `You are 'Modern Nest AI', a sophisticated, friendly, and expert Interior Design Assistant for 'Modern Nest Interiors'.
Your goal is to provide a premium experience, analyze design needs, and collect high-quality leads for the principal designer.

Tone & Voice:
- Professional yet approachable (high-end consultant).
- Encouraging, creative, and visually descriptive.
- Concise but helpful.

Workflow:
1. Welcome & Discovery: Start by welcoming warmly. Ask what brings them today (full home renovation, room makeover, or inspiration).
2. Multimodal Interaction:
   - Image Analysis: If a user uploads a photo, analyze layout, lighting, and style. Provide immediate positive feedback and a 'Quick Design Tip'. Example: "I see a lot of natural light! Adding tall indoor plants and a neutral-toned rug would elevate the warmth."
   - Voice Input: Be naturally conversational.
3. Consultation (Lead Gen): Subtly and politely gather:
   - Scope (1BHK, 2BHK, Villa, or commercial).
   - Style Preference (Modern, Minimalist, Industrial, or Traditional Indian).
   - Budget Range (Economy, Premium, or Luxury).
4. Handling Objections:
   - Cost: "Great design should be accessible. I can help you prioritize where to spend and save."
   - Unsure: "Upload a photo of a room you like, and I'll help define your style."
5. CTA (The Close): Once info is gathered, say: "I’ve noted your preferences. Would you like me to book a free 15-minute consultation with our lead designer via WhatsApp?"

Constraints:
- NEVER give specific pricing (e.g., "₹2 Lakhs"). Use ranges or state the principal designer provides tailored quotes.
- Always maintain the 'Modern Nest' brand prestige.`;

export function DesignAIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Welcome to Modern Nest Interiors! 🏡✨ I'm your AI Interior Design Assistant. What brings you to our studio today? Are you looking for a full home transformation, a specific room makeover, or simply some high-end inspiration?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const handleOpenChat = () => setIsOpen(true);
    window.addEventListener('openAiChat', handleOpenChat);
    
    // Initialize Web Speech API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prev => prev + (prev ? ' ' : '') + transcript);
        setIsRecording(false);
      };

      recognitionRef.current.onerror = () => setIsRecording(false);
      recognitionRef.current.onend = () => setIsRecording(false);
    }

    return () => window.removeEventListener('openAiChat', handleOpenChat);
  }, []);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      setIsRecording(true);
      recognitionRef.current?.start();
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userText = input.trim();
    const userImage = selectedImage;
    
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { role: 'user', text: userText, image: userImage || undefined }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const modelName = "gemini-3-flash-preview";
      
      const contents: any[] = messages.slice(-10).map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const currentParts: any[] = [{ text: userText || "Analyze this image and suggest design improvements." }];
      if (userImage) {
        currentParts.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: userImage.split(',')[1]
          }
        });
      }

      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
            ...contents,
            { role: 'user', parts: currentParts }
        ],
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
        }
      });

      const aiText = response.text || "I apologize, but I'm having trouble processing that right now. Could you try rephrasing?";
      setMessages(prev => [...prev, { role: 'model', text: aiText }]);
    } catch (error) {
      console.error("AI Chat Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I'm having a technical moment. Please try again in a few seconds!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Toggle Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 bg-gold-500 text-charcoal-900 p-4 rounded-full shadow-2xl hover:bg-gold-600 hover:scale-110 transition-all duration-300 flex items-center justify-center cursor-pointer group border-2 border-white dark:border-charcoal-800"
            initial={{ scale: 0, rotate: -45 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 45 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            aria-label="Open AI Interior Design Assistant"
          >
            <Bot size={32} className="group-hover:animate-pulse" />
            <span className="absolute right-full mr-4 bg-white dark:bg-charcoal-800 text-charcoal-900 dark:text-white text-xs font-bold py-2 px-4 rounded-full shadow-lg opacity-0 whitespace-nowrap group-hover:opacity-100 transition-opacity duration-300 translate-x-4 group-hover:translate-x-0 pointer-events-none border border-gold-500/30">
              Modern Nest AI Assistant
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-50 w-[90vw] sm:w-96 md:w-[450px] h-[650px] max-h-[90vh] bg-white dark:bg-charcoal-900 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.5)] overflow-hidden border border-gold-500/20 flex flex-col"
          >
            {/* Header */}
            <div className="bg-charcoal-900 dark:bg-black p-5 flex justify-between items-center text-white border-b border-gold-500/30">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gold-500/20 flex items-center justify-center relative border border-gold-500/30 overflow-hidden">
                  <Bot className="text-gold-500" size={24} />
                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-charcoal-900 rounded-full"></span>
                </div>
                <div>
                  <h4 className="font-serif text-xl leading-tight">Modern Nest AI</h4>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                    <p className="text-[10px] text-gold-400 uppercase tracking-widest font-bold">Online & Ready to Design</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="w-10 h-10 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>

            {/* Messages Body */}
            <div className="flex-grow p-6 bg-gray-50 dark:bg-[#0f0f0f] overflow-y-auto space-y-6 scrollbar-hide">
              {messages.map((msg, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-3 max-w-[88%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${msg.role === 'user' ? 'bg-charcoal-900 text-gold-500 border-gold-500/20' : 'bg-gold-500 text-charcoal-900 border-gold-500'}`}>
                      {msg.role === 'user' ? <User size={14} /> : <Bot size={14} />}
                    </div>
                    <div className="space-y-2">
                        {msg.image && (
                          <div className="rounded-xl overflow-hidden border border-gold-500/20 shadow-md">
                            <img src={msg.image} alt="Uploaded space" className="w-[200px] object-cover h-auto" />
                          </div>
                        )}
                        <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                          msg.role === 'user' 
                            ? 'bg-charcoal-900 text-white rounded-tr-none' 
                            : 'bg-white dark:bg-charcoal-800 text-charcoal-900 dark:text-white rounded-tl-none border border-gold-500/5'
                        }`}>
                          {msg.text}
                        </div>
                    </div>
                  </div>
                </motion.div>
              ))}
              {isLoading && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                  <div className="flex gap-3 items-center bg-white dark:bg-charcoal-800 p-3 rounded-2xl rounded-tl-none border border-gold-500/5">
                    <Loader2 size={16} className="animate-spin text-gold-500" />
                    <span className="text-xs text-gray-400 font-medium italic">Analyzing your space...</span>
                  </div>
                </motion.div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Selected Image Preview */}
            <AnimatePresence>
              {selectedImage && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-6 py-2 bg-gray-100 dark:bg-charcoal-950 flex items-center gap-3 border-t border-gold-500/10"
                >
                  <div className="relative w-12 h-12 rounded-lg border border-gold-500 overflow-hidden">
                    <img src={selectedImage} alt="Selected" className="w-full h-full object-cover" />
                    <button 
                      onClick={() => setSelectedImage(null)}
                      className="absolute inset-0 bg-black/40 flex items-center justify-center text-white opacity-0 hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 font-medium">Image attached. Ask for a tip!</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Input Footer */}
            <div className="p-5 bg-white dark:bg-charcoal-950 border-t border-gold-500/10 space-y-4">
              <div className="flex items-center gap-2 mb-2 px-2">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-gray-500 hover:text-gold-500 hover:bg-gold-500/10 transition-all border border-transparent hover:border-gold-500/20"
                  title="Upload space photo"
                >
                  <Paperclip size={20} />
                </button>
                <button 
                  onClick={toggleRecording}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${
                    isRecording 
                      ? 'bg-red-500 text-white animate-pulse' 
                      : 'text-gray-500 hover:text-gold-500 hover:bg-gold-500/10 hover:border-gold-500/20'
                  }`}
                  title="Voice message"
                >
                  {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden" 
                />
              </div>

              <form onSubmit={handleSend} className="relative flex items-center">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={isRecording ? "Listening..." : "Tell me about your space..."}
                  className="w-full bg-gray-50 dark:bg-charcoal-900 border border-gray-200 dark:border-gray-700 rounded-full py-4 pl-6 pr-14 text-sm focus:outline-none focus:border-gold-500 transition-colors text-charcoal-900 dark:text-white"
                  disabled={isLoading}
                />
                <button 
                  type="submit"
                  disabled={(!input.trim() && !selectedImage) || isLoading}
                  className={`absolute right-2 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                    (!input.trim() && !selectedImage) || isLoading 
                      ? 'bg-gray-200 dark:bg-charcoal-800 text-gray-400' 
                      : 'bg-gold-500 text-charcoal-900 hover:bg-gold-600 shadow-lg cursor-pointer'
                  }`}
                >
                   <Send size={18} />
                </button>
              </form>
              <p className="text-[9px] text-center text-gray-500 mt-3 font-medium uppercase tracking-widest opacity-50 flex items-center justify-center gap-1">
                <Bot size={10} /> Modern Nest Proprietary Designer AI
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
