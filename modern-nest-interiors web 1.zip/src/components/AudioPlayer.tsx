import { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.3);
  const [showVolume, setShowVolume] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const hideTimeout = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // We use a high quality royalty free ambient lofi track
    audioRef.current = new Audio('https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3');
    audioRef.current.loop = true;
    audioRef.current.volume = volume;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(error => console.log("Audio play failed:", error));
    }
    setIsPlaying(!isPlaying);
  };

  const handleMouseEnter = () => {
    if (hideTimeout.current) clearTimeout(hideTimeout.current);
    setShowVolume(true);
  };

  const handleMouseLeave = () => {
    hideTimeout.current = setTimeout(() => {
      setShowVolume(false);
    }, 1500); // 1.5s delay before hiding for better UX
  };

  return (
    <div 
      className="fixed bottom-4 left-4 sm:bottom-6 sm:left-6 z-[100] flex items-center gap-2 sm:gap-3"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <AnimatePresence>
        {showVolume && (
          <motion.div 
            initial={{ opacity: 0, x: -20, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -20, scale: 0.9 }}
            className="bg-charcoal-900/95 backdrop-blur-xl border border-gold-500/30 rounded-full h-12 sm:h-14 px-4 sm:px-5 flex items-center shadow-2xl"
          >
            <div className="flex items-center gap-2 sm:gap-3">
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.01" 
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-20 sm:w-28 accent-gold-500 h-1 cursor-pointer bg-charcoal-800 rounded-lg appearance-none"
              />
              <span className="text-[9px] sm:text-[10px] text-gold-500 font-mono w-6 sm:w-8 text-right font-bold tracking-tighter">
                {Math.round(volume * 100)}%
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1 }}
        onClick={togglePlay}
        className="w-12 h-12 sm:w-14 sm:h-14 bg-charcoal-900 border border-gold-500/50 text-gold-500 rounded-full flex items-center justify-center shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:scale-105 transition-transform cursor-pointer group backdrop-blur-md relative shrink-0"
        aria-label={isPlaying ? "Mute ambient music" : "Play ambient music"}
        title="Toggle Ambient Music"
      >
        <div className="absolute inset-0 rounded-full border border-gold-500/0 group-hover:border-gold-500/50 transition-all scale-110"></div>
        {isPlaying ? (
          <div className="flex items-center gap-0.5">
            <motion.div animate={{ height: [8, 16, 8] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-0.5 bg-gold-500" />
            <motion.div animate={{ height: [12, 16, 12] }} transition={{ repeat: Infinity, duration: 0.7 }} className="w-0.5 bg-gold-500" />
            <motion.div animate={{ height: [10, 16, 10] }} transition={{ repeat: Infinity, duration: 0.6 }} className="w-0.5 bg-gold-500" />
            <Volume2 size={20} className="ml-1" />
          </div>
        ) : (
          <VolumeX size={20} />
        )}
      </motion.button>
    </div>
  );
}
