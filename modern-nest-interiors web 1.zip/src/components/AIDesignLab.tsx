import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Loader2, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export function AIDesignLab() {
  const { t } = useLanguage();
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [processingState, setProcessingState] = useState<'idle' | 'processing' | 'success'>('idle');
  const [progress, setProgress] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPosition(Math.min(Math.max(position, 0), 100));
  };

  const startSimulation = () => {
    setIsModalOpen(true);
    setProcessingState('processing');
    setProgress(0);
  };

  useEffect(() => {
    if (processingState === 'processing') {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setProcessingState('success');
            return 100;
          }
          return prev + 2;
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [processingState]);

  return (
    <section id="ai-design" className="py-24 bg-white dark:bg-charcoal-900 transition-colors duration-300 overflow-hidden">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold"
          >
            {t('ai.tag')}
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-4xl md:text-5xl font-serif leading-tight font-light dark:text-white"
          >
            {t('ai.title')} <span className="italic text-gray-500">{t('ai.accent')}</span>.
          </motion.h2>
          <p className="text-gray-600 dark:text-gray-400 mt-4 font-light text-base md:text-lg">
            {t('ai.desc')}
          </p>
        </div>

        <div className="max-w-5xl mx-auto grid md:grid-cols-12 gap-12 items-center">
          {/* Before & After Slider */}
          <div className="md:col-span-12 lg:col-span-8">
            <div 
              ref={containerRef}
              className="relative aspect-[16/9] rounded-lg overflow-hidden cursor-ew-resize select-none border border-gold-500/20 shadow-2xl"
              onMouseMove={handleMouseMove}
              onTouchMove={handleMouseMove}
            >
              {/* After Image (Furnished) */}
              <div className="absolute inset-0">
                <img 
                  src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=2000" 
                  alt="After" 
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Before Image (Empty) */}
              <div 
                className="absolute inset-0 z-10 overflow-hidden"
                style={{ width: `${sliderPosition}%` }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=2000" 
                  alt="Before" 
                  className="w-full h-full object-cover max-w-none"
                  style={{ width: containerRef.current?.offsetWidth }}
                />
                <div className="absolute inset-0 bg-black/10"></div>
              </div>

              {/* Slider Handle */}
              <div 
                className="absolute top-0 bottom-0 z-20 w-1 bg-gold-500 shadow-[0_0_15px_rgba(212,175,55,0.5)]"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-gold-500 rounded-full flex items-center justify-center text-white shadow-xl border-4 border-white dark:border-charcoal-900 overflow-hidden">
                  <div className="flex gap-1 animate-pulse">
                    <div className="w-1 h-3 bg-white rounded-full"></div>
                    <div className="w-1 h-3 bg-white rounded-full"></div>
                  </div>
                </div>
              </div>

              {/* Labels */}
              <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 z-30 bg-black/50 backdrop-blur-md px-3 py-1 rounded text-white text-[10px] sm:text-xs uppercase tracking-widest">Before Space</div>
              <div className="absolute bottom-4 right-4 sm:bottom-6 sm:right-6 z-30 bg-gold-500/80 backdrop-blur-md px-3 py-1 rounded text-white text-[10px] sm:text-xs uppercase tracking-widest">AI Furnished</div>
            </div>
          </div>

          {/* CTA Area */}
          <div className="md:col-span-12 lg:col-span-4 space-y-8">
            <div className="p-6 sm:p-8 bg-gray-50 dark:bg-charcoal-800 rounded-lg border border-gold-500/10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
                <Sparkles size={60} className="text-gold-500" />
              </div>
              
              <h3 className="text-xl sm:text-2xl font-serif mb-4 dark:text-white">Design Your Room in <span className="text-gold-500">Seconds</span></h3>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 font-light mb-8">
                Upload a photo of your empty room and let our AI create high-end interior layouts tailored to your style preferences.
              </p>
              
              <button 
                onClick={startSimulation}
                className="w-full bg-gold-500 hover:bg-gold-600 text-white py-4 rounded-full flex items-center justify-center gap-3 transition-all active:scale-95 shadow-lg shadow-gold-500/20 group/btn"
              >
                <Sparkles size={20} className="group-hover/btn:rotate-12 transition-transform" />
                <span className="font-medium tracking-wider uppercase text-sm">{t('ai.btn')}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Processing Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-charcoal-900/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="w-full max-w-md bg-white dark:bg-charcoal-800 rounded-2xl shadow-2xl border border-gold-500/20 overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gold-500/10 rounded-full flex items-center justify-center text-gold-500">
                      {processingState === 'success' ? <CheckCircle2 /> : <Sparkles />}
                    </div>
                    <h3 className="text-xl font-serif font-medium dark:text-white">{t('ai.modal.title')}</h3>
                  </div>
                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>

                {processingState === 'processing' && (
                  <div className="space-y-6">
                    <p className="text-gray-600 dark:text-gray-400 font-light">{t('ai.modal.desc')}</p>
                    <div className="relative h-2 bg-gray-100 dark:bg-charcoal-900 rounded-full overflow-hidden">
                      <motion.div 
                        className="absolute h-full bg-gold-500 shadow-[0_0_10px_rgba(212,175,55,0.5)]"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-center gap-2 text-gold-500 text-sm font-medium">
                      <Loader2 className="animate-spin" size={16} />
                      <span>{Math.round(progress)}% Optimized</span>
                    </div>
                  </div>
                )}

                {processingState === 'success' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center space-y-6"
                  >
                    <div className="py-4 font-light text-gray-600 dark:text-gray-400">
                      <p className="text-lg text-gold-500 font-medium mb-2">{t('ai.modal.success')}</p>
                      <p>Multiple premium layouts have been generated for your space based on luxury minimalist aesthetics.</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="aspect-square rounded-lg bg-gray-200 dark:bg-charcoal-900 overflow-hidden border border-gold-500/10 group cursor-pointer">
                        <img src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                      </div>
                      <div className="aspect-square rounded-lg bg-gray-200 dark:bg-charcoal-900 overflow-hidden border border-gold-500/10 group cursor-pointer">
                        <img src="https://images.unsplash.com/photo-1616137466211-f939a420be84?auto=format&fit=crop&q=80&w=400" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                      </div>
                    </div>
                    <div className="flex flex-col gap-3">
                      <button 
                        onClick={() => {
                          setIsModalOpen(false);
                          window.dispatchEvent(new CustomEvent('openAiChat'));
                        }}
                        className="w-full py-4 rounded-full bg-gold-500 text-charcoal-900 font-bold uppercase tracking-widest text-xs hover:bg-gold-600 transition-colors shadow-lg"
                      >
                        Chat with Designer AI
                      </button>
                      <button 
                        onClick={() => setIsModalOpen(false)}
                        className="w-full py-4 rounded-full border border-gray-200 dark:border-gray-700 text-charcoal-900 dark:text-white font-medium uppercase tracking-widest text-xs hover:bg-gray-100 dark:hover:bg-white/10 transition-colors"
                      >
                        Keep Exploring
                      </button>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
