import { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator } from 'lucide-react';

const ROOM_MULTIPLIERS: Record<string, number> = {
  "Living Room": 1.2,
  "Kitchen": 1.5,
  "Bedroom": 1.0,
  "Bathroom": 1.3,
  "Full Home (2BHK)": 3.5,
  "Full Home (3BHK)": 4.5
};

const QUALITY_RATES: Record<string, number> = {
  "Standard": 2000,
  "Premium": 3500,
  "Ultra-Luxury": 6000
};

export function BudgetEstimator() {
  const [roomType, setRoomType] = useState("Living Room");
  const [quality, setQuality] = useState("Premium");
  const [size, setSize] = useState<number | ''>(200);

  const calculateEstimate = () => {
    const numericSize = typeof size === 'number' ? size : 0;
    if (roomType.includes("Full Home")) {
      // flat rate for full homes as a base example
      return QUALITY_RATES[quality] * ROOM_MULTIPLIERS[roomType] * (numericSize > 0 ? numericSize / 500 : 1);
    }
    return QUALITY_RATES[quality] * ROOM_MULTIPLIERS[roomType] * numericSize;
  };

  const estimate = calculateEstimate();

  return (
    <section className="py-24 bg-white dark:bg-charcoal-900 transition-colors duration-300">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="md:w-1/2"
          >
            <h4 className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold">Instant Quote</h4>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif leading-tight font-light text-charcoal-900 dark:text-white mb-6">
              Interactive Budget <span className="italic text-gray-400">Estimator</span>.
            </h2>
            <p className="text-gray-600 dark:text-gray-400 font-light text-base md:text-lg mb-8">
              Plan your dream space with confidence. Use our calculator to get an instant estimate to guide your next interior masterpiece.
            </p>
            <div className="bg-gray-50 dark:bg-charcoal-800 p-8 rounded-sm border border-gray-100 dark:border-gray-800">
              <p className="text-sm uppercase tracking-widest text-gray-500 dark:text-gray-400 mb-2 font-medium">Estimated Range</p>
              <div className="flex items-center gap-4">
                <Calculator className="text-gold-500" size={32} />
                <motion.h3 
                  key={estimate}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-4xl md:text-5xl font-serif text-charcoal-900 dark:text-white tracking-wide"
                >
                  ₹{(estimate * 0.8).toLocaleString('en-IN', { maximumFractionDigits: 0 })} <span className="text-2xl text-gray-400 font-light">-</span> ₹{(estimate * 1.2).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </motion.h3>
              </div>
              <p className="text-xs text-gray-400 uppercase tracking-wider mt-4">*This is a rough estimate and pricing may vary</p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="md:w-1/2 w-full space-y-6"
          >
            <div>
              <label className="block text-sm uppercase tracking-wider text-charcoal-900 dark:text-gray-300 mb-3 font-semibold">Select Room Type</label>
              <select 
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white focus:outline-none focus:border-gold-500 transition-colors font-light text-lg appearance-none"
              >
                {Object.keys(ROOM_MULTIPLIERS).map(type => (
                  <option key={type} className="dark:bg-charcoal-800" value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm uppercase tracking-wider text-charcoal-900 dark:text-gray-300 mb-3 font-semibold mt-8">Material Quality</label>
              <div className="grid grid-cols-3 gap-4">
                {Object.keys(QUALITY_RATES).map(q => (
                  <button
                    key={q}
                    onClick={() => setQuality(q)}
                    className={`py-3 px-2 border rounded-sm text-sm uppercase tracking-wider transition-all duration-300 ${
                      quality === q 
                        ? 'bg-charcoal-900 text-white border-charcoal-900 dark:bg-gold-500 dark:text-charcoal-900 dark:border-gold-500' 
                        : 'border-gray-300 dark:border-gray-700 text-gray-500 hover:border-gold-500'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm uppercase tracking-wider text-charcoal-900 dark:text-gray-300 mb-3 font-semibold mt-8">Approximate Size (Sq. Ft.)</label>
              <input 
                type="number"
                value={size}
                onChange={(e) => setSize(e.target.value === '' ? '' : parseInt(e.target.value))}
                placeholder="200"
                className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white focus:outline-none focus:border-gold-500 transition-colors font-light text-lg"
              />
            </div>
            
          </motion.div>

        </div>
      </div>
    </section>
  );
}
