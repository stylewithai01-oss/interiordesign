import { motion } from 'motion/react';
import { ChefHat, BedDouble, Building2 } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export function Services() {
  const { t } = useLanguage();

  const SERVICES = [
    {
      icon: <ChefHat size={36} strokeWidth={1} />,
      title: t('srv.k.title'),
      description: t('srv.k.desc'),
    },
    {
      icon: <BedDouble size={36} strokeWidth={1} />,
      title: t('srv.b.title'),
      description: t('srv.b.desc'),
    },
    {
      icon: <Building2 size={36} strokeWidth={1} />,
      title: t('srv.o.title'),
      description: t('srv.o.desc'),
    }
  ];

  return (
    <section id="services" className="py-24 md:py-32 bg-white dark:bg-charcoal-900 transition-colors duration-300">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold"
          >
            {t('srv.tag')}
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-4xl md:text-5xl font-serif leading-tight font-light dark:text-white"
          >
            {t('srv.title')} <span className="italic text-gray-500">{t('srv.accent')}</span>.
          </motion.h2>
        </div>

        {/* 3-Column Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="bg-gray-50 dark:bg-charcoal-800 p-12 text-center rounded-sm hover:-translate-y-2 border border-transparent hover:border-gold-500/20 transition-all duration-300 group shadow-sm hover:shadow-md"
            >
              <div className="w-20 h-20 mx-auto rounded-full bg-white dark:bg-charcoal-900 shadow-sm flex items-center justify-center text-charcoal-800 dark:text-gray-200 mb-8 group-hover:text-gold-500 transition-all duration-500">
                 {service.icon}
              </div>
              <h3 className="text-2xl font-serif font-medium mb-4 text-charcoal-900 dark:text-white group-hover:text-gold-600 transition-colors">{service.title}</h3>
              <p className="text-gray-600 dark:text-gray-400 font-light leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
