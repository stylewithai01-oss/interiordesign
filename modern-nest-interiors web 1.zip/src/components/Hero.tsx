import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export function Hero() {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-charcoal-900">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=2560"
          alt="Luxury modern living room"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay for contrast */}
        <div className="absolute inset-0 bg-charcoal-900/60"></div>
      </div>

      <div className="container mx-auto px-6 md:px-12 relative z-10 text-white">
        <div className="max-w-4xl text-center mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center"
          >
            <span className="inline-block py-1 px-4 border border-white/20 rounded-full text-xs uppercase tracking-[0.2em] mb-8 text-gold-400">
              {t('hero.tag')}
            </span>
          </motion.div>
          
          <motion.h1
            className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-serif leading-[1.1] mb-8 font-light"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {t('hero.title')} <span className="italic text-gold-400">{t('hero.accent')}</span>.
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex justify-center"
          >
            <a 
              href="#portfolio" 
              className="bg-gold-500 hover:bg-gold-600 text-white px-10 py-5 rounded-full uppercase tracking-wider text-sm transition-all hover:scale-105 flex items-center gap-3 font-medium"
            >
              {t('hero.btn')} <ArrowRight size={18} />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
