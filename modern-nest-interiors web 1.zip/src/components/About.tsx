import { motion } from 'motion/react';
import { Check } from 'lucide-react';

const REASONS = [
  "Customized design solutions",
  "Budget-friendly packages",
  "On-time project delivery",
  "Experienced design team"
];

export function About() {
  return (
    <section id="about" className="py-24 md:py-32 bg-beige-50">
      <div className="container mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* The oval mask applies the luxury prestige recipe style */}
            <div className="oval-mask aspect-[3/4] w-full max-w-md mx-auto overflow-hidden shadow-2xl relative z-10">
              <img 
                src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=1200" 
                alt="Refined Interior Details" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-2xl shadow-xl z-20 max-w-xs hidden md:block">
              <p className="font-serif italic text-2xl mb-2">"We believe every space has a story to tell."</p>
              <p className="text-sm uppercase tracking-widest text-gold-500 font-medium">— Ananya Mehta</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h4 className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold">About Us</h4>
            <h2 className="text-4xl md:text-5xl font-serif mb-6 leading-tight">
              Elevating Everyday <span className="italic text-gray-500">Living</span>.
            </h2>
            
            <p className="text-lg text-gray-600 mb-6 font-light leading-relaxed">
              Founded by Ananya Mehta, UrbanNest Interiors is a premier interior design studio based in Pune. 
              We specialize in transforming ordinary houses into extraordinary homes, and commercial spaces into 
              inspiring environments.
            </p>
            
            <p className="text-lg text-gray-600 mb-10 font-light leading-relaxed">
              Our philosophy is rooted in minimalism, functional luxury, and the thoughtful use of materials. 
              We handle everything from concept to completion, ensuring a seamless experience.
            </p>

            <div className="space-y-4 mb-10">
              {REASONS.map((reason, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-gold-50 flex items-center justify-center text-gold-500 shrink-0">
                    <Check size={14} />
                  </div>
                  <span className="text-gray-800 font-medium">{reason}</span>
                </div>
              ))}
            </div>

            <a href="#portfolio" className="pill-button hover:bg-dark-900 hover:text-white border-dark-900 text-dark-900 inline-block">
              Discover Our Work
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
