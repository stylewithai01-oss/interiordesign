import { motion } from 'motion/react';
import { Play } from 'lucide-react';

const PROJECTS = [
  {
    title: "The Belvedere Penthouse",
    image: "https://images.unsplash.com/photo-1600607688969-a5bfcd64bd95?auto=format&fit=crop&q=80&w=1200",
  },
  {
    title: "Minimalist Townhouse",
    image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=1200",
  },
  {
    title: "Luxury Suite",
    image: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&q=80&w=1200",
  },
  {
    title: "Aria Corporate HQ",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200",
  },
  {
    title: "Monochrome Study",
    image: "https://images.unsplash.com/photo-1600210491369-e753d80a41f3?auto=format&fit=crop&q=80&w=1200",
  },
  {
    title: "Golden Hour Kitchen",
    image: "https://images.unsplash.com/photo-1556912173-3bb406ef7e77?auto=format&fit=crop&q=80&w=1200",
  }
];

export function Portfolio() {
  return (
    <section id="portfolio" className="py-24 md:py-32 bg-charcoal-900 text-white">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center mb-20 max-w-3xl mx-auto">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-400 mb-4 font-semibold"
          >
            Gallery
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif leading-tight font-light"
          >
            Our Design <span className="italic text-gray-400">Portfolio</span>.
          </motion.h2>
        </div>

        {/* Responsive Grid Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-32">
          {PROJECTS.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (index % 3) * 0.1, duration: 0.8 }}
              className="group cursor-pointer relative overflow-hidden"
            >
              <div className="aspect-[4/5] w-full bg-charcoal-800">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 filter brightness-90 group-hover:brightness-100"
                />
              </div>
              
              {/* Image Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-between p-8">
                
                {/* Pinterest Save Button (shows on hover) */}
                <div className="self-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 delay-100">
                  <a
                    href={`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(window.location.href)}&media=${encodeURIComponent(project.image)}&description=${encodeURIComponent(project.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#E60023] hover:bg-[#c9001e] text-white flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-wide shadow-lg"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.367 18.614 0 12.017 0z"/>
                    </svg>
                    Save
                  </a>
                </div>

                <h3 className="text-2xl font-serif text-white tracking-wide">{project.title}</h3>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Video Tour Section */}
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10">
            <motion.h4 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-sm uppercase tracking-[0.2em] text-gold-400 mb-4 font-semibold"
            >
              Immerse Yourself
            </motion.h4>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-serif leading-tight font-light"
            >
              YouTube Video Tour
            </motion.h2>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="aspect-video w-full bg-charcoal-800 relative group cursor-pointer overflow-hidden border border-gray-800"
          >
            {/* Fallback Image mimicking video thumbnail */}
            <img 
               src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=1600" 
               alt="Video Thumbnail" 
               className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 bg-charcoal-900/80 rounded-full flex items-center justify-center backdrop-blur-sm border border-gold-500/50 group-hover:bg-gold-500 group-hover:scale-110 transition-all duration-300">
                <Play className="text-white ml-2" size={32} fill="currentColor" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
