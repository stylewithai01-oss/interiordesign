import { motion } from 'motion/react';
import { MapPin, Phone, Mail } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 bg-white dark:bg-[#151515] relative transition-colors duration-300">
      <div className="container mx-auto px-6 md:px-12 relative z-10">
        
        <div className="text-center mb-16">
          <motion.h4 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold"
          >
            Get In Touch
          </motion.h4>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif leading-tight font-light text-charcoal-900 dark:text-white"
          >
            Contact & <span className="italic text-gray-500">Location</span>.
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 lg:gap-16 max-w-6xl mx-auto shadow-2xl overflow-hidden rounded-sm border border-gray-100 dark:border-gray-800 bg-white dark:bg-charcoal-900 transition-colors duration-300">
          
          {/* Left: Professional Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="p-10 md:p-14 order-2 md:order-1"
          >
            <h3 className="text-2xl font-serif mb-8 text-charcoal-900 dark:text-white">Send an Inquiry</h3>
            <form className="space-y-6">
              <div>
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm"
                />
                <input 
                  type="tel" 
                  placeholder="Phone Number" 
                  className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm"
                />
              </div>
              <div>
                <select 
                  defaultValue=""
                  className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-gray-500 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm appearance-none"
                >
                  <option value="" disabled>Select Service</option>
                  <option value="kitchen" className="dark:bg-charcoal-800">Modular Kitchen</option>
                  <option value="bedroom" className="dark:bg-charcoal-800">Luxury Bedroom</option>
                  <option value="office" className="dark:bg-charcoal-800">Corporate Office</option>
                </select>
              </div>
              <div>
                <textarea 
                  placeholder="Project Details" 
                  rows={4}
                  className="w-full bg-transparent border-b border-gray-300 dark:border-gray-700 py-3 px-0 text-charcoal-900 dark:text-white placeholder-gray-500 focus:outline-none focus:border-gold-500 transition-colors font-light text-sm resize-none"
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="bg-charcoal-900 dark:bg-gold-500 hover:bg-gold-500 dark:hover:bg-gold-600 text-white dark:text-charcoal-900 px-8 py-4 w-full uppercase tracking-widest text-xs font-semibold transition-colors mt-6"
              >
                Submit Request
              </button>
            </form>
          </motion.div>

          {/* Right: Embedded Google Maps */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="h-[400px] md:h-auto order-1 md:order-2 bg-gray-100 relative"
          >
            {/* Replace this src with your actual business Google Maps embed URL */}
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15132.880879555026!2d73.83492723955078!3d18.518973699999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2bfbe392750e3%3A0xcb135bbce6ebcaec!2sPune%2C%20Maharashtra%2C%20India!5e0!3m2!1sen!2sus!4v1714488277259!5m2!1sen!2sus" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0 w-full h-full"
            ></iframe>
            
            {/* Floating Info Box on Map */}
            <div className="absolute bottom-6 right-6 bg-white p-6 shadow-xl max-w-[280px]">
              <div className="flex items-start gap-4 mb-3">
                <MapPin className="text-gold-500 mt-1 shrink-0" size={18} />
                <div>
                  <h5 className="font-semibold tracking-wider uppercase text-[10px] text-gray-500 mb-1">Our Studio</h5>
                  <p className="text-charcoal-900 font-medium text-sm leading-snug">
                    45 Luxury Avenue,<br />
                    Design District, NY 10001
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Phone className="text-gold-500 mt-1 shrink-0" size={18} />
                <p className="text-charcoal-900 font-medium text-sm">
                  +1 (555) 123-4567
                </p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
