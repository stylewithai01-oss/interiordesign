import { motion } from 'motion/react';
import { Instagram, MessageCircle } from 'lucide-react';

export function SocialConnect() {
  return (
    <section className="py-24 bg-gray-50 dark:bg-[#111111] border-t border-b border-gray-200 dark:border-gray-800 transition-colors duration-300">
      <div className="container mx-auto px-6 md:px-12 text-center">
        <motion.h4 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-sm uppercase tracking-[0.2em] text-gold-500 mb-4 font-semibold"
        >
          Stay Inspired
        </motion.h4>
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-serif leading-tight mb-12 font-light text-charcoal-900 dark:text-white"
        >
          Connect With Us <span className="italic text-gray-500">Instantly</span>.
        </motion.h2>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="flex flex-col sm:flex-row justify-center items-center gap-6"
        >
          <a 
            href="https://instagram.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-charcoal-900 dark:bg-white text-white dark:text-charcoal-900 px-8 py-4 w-full sm:w-auto rounded-full hover:bg-gold-500 dark:hover:bg-gold-500 dark:hover:text-white transition-colors"
          >
            <Instagram size={20} />
            <span className="uppercase tracking-wider text-sm font-medium">Follow on Instagram</span>
          </a>
          
          <a 
            href="https://wa.me/1234567890" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-3 bg-[#25D366] text-white px-8 py-4 w-full sm:w-auto rounded-full hover:bg-[#1ebd59] transition-colors"
          >
            <MessageCircle size={20} />
            <span className="uppercase tracking-wider text-sm font-medium">Chat on WhatsApp</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
