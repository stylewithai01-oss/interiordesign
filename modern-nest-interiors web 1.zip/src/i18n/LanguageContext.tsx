import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

type Language = 'en' | 'kn';

interface Translations {
  [key: string]: {
    en: string;
    kn: string;
  };
}

const translations: Translations = {
  // Nav
  'nav.home': { en: 'Home', kn: 'ಮುಖಪುಟ' },
  'nav.services': { en: 'Services', kn: 'ಸೇವೆಗಳು' },
  'nav.portfolio': { en: 'Portfolio', kn: 'ಪೋರ್ಟ್ಫೋಲಿಯೊ' },
  'nav.contact': { en: 'Contact', kn: 'ಸಂಪರ್ಕ' },

  // Hero
  'hero.tag': { en: 'Modern Nest Interiors', kn: 'ಮಾಡರ್ನ್ ನೆಸ್ಟ್ ಇಂಟೀರಿಯರ್ಸ್' },
  'hero.title': { en: 'Transform Your Space into a', kn: 'ನಿಮ್ಮ ಜಾಗವನ್ನು ಮೇರುಕೃತಿಯಾಗಿ' },
  'hero.accent': { en: 'Masterpiece', kn: 'ಪರಿವರ್ತಿಸಿ' },
  'hero.btn': { en: 'View Our Work', kn: 'ನಮ್ಮ ಕೆಲಸಗಳನ್ನು ವೀಕ್ಷಿಸಿ' },

  // Services
  'srv.tag': { en: 'Our Expertise', kn: 'ನಮ್ಮ ಪರಿಣತಿ' },
  'srv.title': { en: 'Sophisticated', kn: 'ಅತ್ಯಾಧುನಿಕ' },
  'srv.accent': { en: 'Services', kn: 'ಸೇವೆಗಳು' },
  'srv.k.title': { en: 'Modular Kitchen', kn: 'ಮಾಡ್ಯುಲರ್ ಕಿಚನ್' },
  'srv.k.desc': { en: 'State-of-the-art kitchen designs blending ergonomics with luxury materials for a seamless culinary experience.', kn: 'ದಕ್ಷತಾಶಾಸ್ತ್ರ ಮತ್ತು ಐಷಾರಾಮಿ ವಸ್ತುಗಳ ಸಂಯೋಜನೆಯೊಂದಿಗೆ ಅತ್ಯಾಧುನಿಕ ಅಡುಗೆಮನೆ ವಿನ್ಯಾಸಗಳು.' },
  'srv.b.title': { en: 'Luxury Bedroom', kn: 'ಐಷಾರಾಮಿ ಮಲಗುವ ಕೋಣೆ' },
  'srv.b.desc': { en: 'Bespoke bedroom sanctuaries tailored for comfort, relaxation, and unmatched personal elegance.', kn: 'ಆರಾಮ, ವಿಶ್ರಾಂತಿ ಮತ್ತು ಸಾಟಿಯಿಲ್ಲದ ವೈಯಕ್ತಿಕ ಸೊಬಗಿಗಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಬೆಡ್‌ರೂಂಗಳು.' },
  'srv.o.title': { en: 'Corporate Office Design', kn: 'ಕಾರ್ಪೊರೇಟ್ ಕಚೇರಿ ವಿನ್ಯಾಸ' },
  'srv.o.desc': { en: 'Elevating workspaces to inspire creativity and professionalism while reflecting your brand\'s prestige.', kn: 'ಸೃಜನಶೀಲತೆ ಮತ್ತು ವೃತ್ತಿಪರತೆಯನ್ನು ಪ್ರೇರೇಪಿಸುವ ಕಚೇರಿ ವಿನ್ಯಾಸಗಳು.' },

  // Virtual Tour
  'tour.tag': { en: 'Immersive Experience', kn: 'ತಲ್ಲೀನಗೊಳಿಸುವ ಅನುಭವ' },
  'tour.title': { en: '360° View', kn: '360° ವರ್ಚುವಲ್ ಟೂರ್' },
  'tour.accent': { en: 'Experience', kn: 'ಅನುಭವ' },
  'tour.label': { en: 'Experience our Design in 360°', kn: 'ನಮ್ಮ ವಿನ್ಯಾಸವನ್ನು 360° ನಲ್ಲಿ ಅನುಭವಿಸಿ' },
  'tour.desc': { en: 'Drag inside the image to look around the room.', kn: 'ಕೋಣೆಯನ್ನು ನೋಡಲು ಚಿತ್ರದ ಒಳಗೆ ಎಳೆಯಿರಿ.' },

  // AI Design Lab
  'ai.tag': { en: 'AI Design Lab', kn: 'ಎಐ ಡಿಸೈನ್ ಲ್ಯಾಬ್' },
  'ai.title': { en: 'Virtual', kn: 'ವರ್ಚುವಲ್' },
  'ai.accent': { en: 'Transformation', kn: 'ಪರಿವರ್ತನೆ' },
  'ai.desc': { en: 'Watch our AI transform empty spaces into luxury masterpieces instantly.', kn: 'ಖಾಲಿ ಜಾಗಗಳು ತಕ್ಷಣವೇ ಐಷಾರಾಮಿ ಮೇರುಕೃತಿಗಳಾಗಿ ಬದಲಾಗುವುದನ್ನು ವೀಕ್ಷಿಸಿ.' },
  'ai.btn': { en: 'Try AI Magic', kn: 'ಎಐ ಮ್ಯಾಜಿಕ್ ಪ್ರಯತ್ನಿಸಿ' },
  'ai.modal.title': { en: 'AI Interior Processing', kn: 'ಎಐ ಇಂಟೀರಿಯರ್ ಪ್ರೊಸೆಸಿಂಗ್' },
  'ai.modal.desc': { en: 'Our AI is analyzing your space and generating premium design options...', kn: 'ನಮ್ಮ ಎಐ ನಿಮ್ಮ ಜಾಗವನ್ನು ವಿಶ್ಲೇಷಿಸುತ್ತಿದೆ ಮತ್ತು ಪ್ರೀಮಿಯಂ ವಿನ್ಯಾಸ ಆಯ್ಕೆಗಳನ್ನು ಸಿದ್ಧಪಡಿಸುತ್ತಿದೆ...' },
  'ai.modal.success': { en: 'Design Optimized Successfully!', kn: 'ವಿನ್ಯಾಸ ಅತ್ಯುತ್ತಮವಾಗಿ ಪೂರ್ಣಗೊಂಡಿದೆ!' },

  // Portfolio
  'port.tag': { en: 'Gallery', kn: 'ಗ್ಯಾಲರಿ' },
  'port.title': { en: 'Our Design', kn: 'ನಮ್ಮ ವಿನ್ಯಾಸ' },
  'port.accent': { en: 'Portfolio', kn: 'ಪೋರ್ಟ್ಫೋಲಿಯೊ' },
  
  // Testimonials
  'test.tag': { en: 'Client Experiences', kn: 'ಗ್ರಾಹಕರ ಅನುಭವಗಳು' },
  'test.title': { en: 'Testimonials &', kn: 'ಪ್ರಶಂಸಾಪತ್ರಗಳು ಮತ್ತು' },
  'test.accent': { en: 'Reviews', kn: 'ವಿಮರ್ಶೆಗಳು' },
  'test.btn': { en: 'Submit a Review', kn: 'ವಿಮರ್ಶೆಯನ್ನು ಸಲ್ಲಿಸಿ' },

  // Budget
  'calc.tag': { en: 'Instant Quote', kn: 'ತ್ವರಿತ ಉಲ್ಲೇಖ' },
  'calc.title': { en: 'Interactive Budget', kn: 'ಇಂಟರಾಕ್ಟಿವ್ ಬಜೆಟ್' },
  'calc.accent': { en: 'Estimator', kn: 'ಎಸ್ಟಿಮೇಟರ್' },
  'calc.desc': { en: 'Plan your dream space with confidence. Use our calculator to get an instant estimate to guide your next interior masterpiece.', kn: 'ನಿಮ್ಮ ಕನಸಿನ ಜಾಗವನ್ನು ವಿಶ್ವಾಸದಿಂದ ಯೋಜಿಸಿ. ತ್ವರಿತ ಅಂದಾಜು ಪಡೆಯಲು ನಮ್ಮ ಕ್ಯಾಲ್ಕುಲೇಟರ್ ಬಳಸಿ.' },
  
  // Contact
  'contact.tag': { en: 'Get In Touch', kn: 'ಸಂಪರ್ಕದಲ್ಲಿರಿ' },
  'contact.title': { en: 'Contact &', kn: 'ಸಂಪರ್ಕ ಮತ್ತು' },
  'contact.accent': { en: 'Location', kn: 'ಸ್ಥಳ' },
  'contact.form': { en: 'Send an Inquiry', kn: 'ವಿಚಾರಣೆ ಕಳುಹಿಸಿ' },
  'contact.submit': { en: 'Submit Request', kn: 'ವಿನಂತಿಯನ್ನು ಸಲ್ಲಿಸಿ' },

  // Footer
  'footer.rights': { en: 'All rights reserved.', kn: 'ಎಲ್ಲ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  // Update font family based on language for better Kannada rendering
  useEffect(() => {
    if (language === 'kn') {
      document.body.style.fontFamily = "'Tiro Kannada', serif, 'Inter', sans-serif";
    } else {
      document.body.style.fontFamily = "";
    }
  }, [language]);

  const t = (key: string) => {
    if (translations[key] && translations[key][language]) {
      return translations[key][language];
    }
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
