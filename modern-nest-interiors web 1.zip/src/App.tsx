import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BudgetEstimator } from './components/BudgetEstimator';
import { Services } from './components/Services';
import { AIDesignLab } from './components/AIDesignLab';
import { VirtualTour } from './components/VirtualTour';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { SocialConnect } from './components/SocialConnect';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { DesignAIChat } from './components/DesignAIChat';
import { AudioPlayer } from './components/AudioPlayer';

export default function App() {
  return (
    <div className="min-h-screen bg-white transition-colors duration-300">
      <Navbar />
      <Hero />
      <Services />
      <AIDesignLab />
      <BudgetEstimator />
      <VirtualTour />
      <Portfolio />
      <Testimonials />
      <SocialConnect />
      <Contact />
      <Footer />
      <DesignAIChat />
      <AudioPlayer />
    </div>
  );
}
